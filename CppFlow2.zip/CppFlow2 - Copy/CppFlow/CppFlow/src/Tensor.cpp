//
// Created by sergio on 13/05/19.
//

#include "../include/Tensor.h"
#include <tensorflow/c/c_api.h>

#include <utility>
#include <cstdint>

class TensorImpl {
public:
  TensorImpl(const ModelImpl& model, const std::string& operation);

  // Rule of five, moving is easy as the pointers can be copied, copying not as i have no idea how to copy
  // the contents of the pointer (i guess dereferencing won't do a deep copy)
  TensorImpl(const TensorImpl& tensor) = delete;
  TensorImpl(TensorImpl&& tensor) = default;
  TensorImpl& operator=(const TensorImpl& tensor) = delete;
  TensorImpl& operator=(TensorImpl&& tensor) = default;

  ~TensorImpl();

  void clean();

  template<typename T>
  void set_data(std::vector<T> new_data);

  template<typename T>
  void set_data(std::vector<T> new_data, const std::vector<int64_t>& new_shape);

  template<typename T>
  std::vector<T> get_data();

  std::vector<int64_t> get_shape();

public:
  TF_Tensor* val;
  TF_Output op;
  TF_DataType type;
  std::vector<int64_t> shape;
  std::unique_ptr<std::vector<int64_t>> actual_shape;
  void* data;
  int flag;

  // Aux functions
  void error_check(bool condition, const std::string& error);

  template <typename T>
  static TF_DataType deduce_type();

  void deduce_shape();

public:
  friend class Model;
};

class ModelImpl {
public:
  // Pass a path to the ModelImpl file and optional TensorImplflow config options. See examples/load_ModelImpl/main.cpp.
  explicit ModelImpl(const std::string& ModelImpl_filename, const std::vector<uint8_t>& config_options = {});

  // Rule of five, moving is easy as the pointers can be copied, copying not as i have no idea how to copy
  // the contents of the pointer (i guess dereferencing won't do a deep copy)
  ModelImpl(const ModelImpl& ModelImpl) = delete;
  ModelImpl(ModelImpl&& ModelImpl) = default;
  ModelImpl& operator=(const ModelImpl& ModelImpl) = delete;
  ModelImpl& operator=(ModelImpl&& ModelImpl) = default;

  ~ModelImpl();

  void init();
  void restore(const std::string& ckpt);
  void save(const std::string& ckpt);
  std::vector<std::string> get_operations() const;

  // Original Run
  void run(const std::vector<TensorImpl*>& inputs, const std::vector<TensorImpl*>& outputs);

  // Run with references
  void run(TensorImpl& input, const std::vector<TensorImpl*>& outputs);
  void run(const std::vector<TensorImpl*>& inputs, TensorImpl& output);
  void run(TensorImpl& input, TensorImpl& output);

  // Run with pointers
  void run(TensorImpl* input, const std::vector<TensorImpl*>& outputs);
  void run(const std::vector<TensorImpl*>& inputs, TensorImpl* output);
  void run(TensorImpl* input, TensorImpl* output);

  TF_Graph* graph;
  TF_Session* session;
  TF_Status* status;

  // Read a file from a string
  static TF_Buffer* read(const std::string&);

  bool status_check(bool throw_exc) const;
  void error_check(bool condition, const std::string& error) const;

public:
  friend class TensorImpl;
};


TensorImpl::TensorImpl(const ModelImpl& model, const std::string& operation) {

    // Get operation by the name
    this->op.oper = TF_GraphOperationByName(model.graph, operation.c_str());
    this->op.index = 0;

    // Operation did not exists
    error_check(this->op.oper != nullptr, "No operation named \"" + operation + "\" exists" );

    // DIMENSIONS

    // Get number of dimensions
    int n_dims = TF_GraphGetTensorNumDims(model.graph, this->op, model.status);

    // DataType
    this->type = TF_OperationOutputType(this->op);

    // If is not a scalar
    if (n_dims > 0) {
        // Get dimensions
        auto *dims = new int64_t[n_dims];
        TF_GraphGetTensorShape(model.graph, this->op, dims, n_dims, model.status);

        // Check error on Model Status
        model.status_check(true);

        this->shape = std::vector<int64_t>(dims, dims + n_dims);

        // Only one dimension can be unknown using this constructor
        // error_check(std::count(this->shape.begin(), this->shape.end(), -1) <= 1, "At most one dimension can be unknown");

        delete[] dims;
    }

    this->flag = 0;
    this->val = nullptr;
    this->data = nullptr;
}

TensorImpl::~TensorImpl() {
    this->clean();
}



void TensorImpl::clean() {
    if (this->flag == 1) {
        TF_DeleteTensor(this->val);
        this->flag = 0;
    }
    this->data = nullptr;
}

void  TensorImpl::error_check(bool condition, const std::string &error) {
    if (!condition) {
        this->flag = -1;
        throw std::runtime_error(error);
    }
}

template<typename T>
void TensorImpl::set_data(std::vector<T> new_data) {

    //Non empty tensor
    if (this->flag == 1) {
        TF_DeleteTensor(this->val);
        this->flag = 0;
    }

    // Check Tensor is valid
    this->error_check(this->flag != -1, "Tensor is not valid");

    // Check type
    this->error_check(deduce_type<T>() == this->type, "Provided type is different from Tensor expected type");

    // Dimensions must be known
    this->error_check(!this->shape.empty(), "Shape of the input Tensor is not known, please provide a shape");

    // At most one dimension can be unknown
    this->error_check(std::count(this->shape.begin(), this->shape.end(), -1) >= -1, "At most one dimension can be unknown, please provide a shape");

    // Check number of elements
    auto exp_size = std::abs(std::accumulate(this->shape.begin(), this->shape.end(), 1, std::multiplies<int64_t>()));

    this->error_check(new_data.size() % exp_size == 0, "Expected and provided number of elements do not match");

    // Deallocator
    auto d = [](void* ddata, size_t, void*) {free(static_cast<T*>(ddata));};


    // Calculate actual shape of unknown dimensions
    this->actual_shape = std::make_unique<decltype(actual_shape)::element_type>(shape.begin(), shape.end());
    std::replace_if (actual_shape->begin(), actual_shape->end(), [](int64_t r) {return r==-1;}, new_data.size()/exp_size);

    // Saves data on class
    this->data = malloc(sizeof(T) * new_data.size());
    memcpy(this->data, new_data.data(), sizeof(T) * new_data.size());

    this->val = TF_NewTensor(this->type, actual_shape->data(), actual_shape->size(), this->data, sizeof(T) * new_data.size(), d, nullptr);


    this->error_check(this->val != nullptr, "An error occurred allocating the Tensor memory");

    this->flag = 1;
}

template<typename T> void TensorImpl::set_data(std::vector<T> new_data, const std::vector<int64_t>& new_shape) {

    this->error_check(this->shape.empty() || this->shape.size() == new_shape.size(), "Provided shape has different number of dimensions");
    auto old_shape = this->shape;

    this->shape = new_shape;
    this->set_data(new_data);

    this->shape = old_shape;
}

template<typename T>
std::vector<T> TensorImpl::get_data() {

    // Check Tensor is valid
    this->error_check(this->flag != -1, "Tensor is not valid");

    // Check type
    this->error_check(deduce_type<T>() == this->type, "Expected return type is different from Tensor type");

    // Tensor is not empty
    this->error_check(this->flag != 0, "Tensor is empty");


    // Check tensor data is not empty
    auto raw_data = TF_TensorData(this->val);
    this->error_check(raw_data != nullptr, "Tensor data is empty");

    size_t size = TF_TensorByteSize(this->val) / TF_DataTypeSize(TF_TensorType(this->val));

    // Convert to correct type
    const auto T_data = static_cast<T*>(raw_data);
    return std::vector<T>(T_data, T_data + size);
}

std::vector<int64_t> TensorImpl::get_shape() {
	return shape;
}

template<typename T>
TF_DataType TensorImpl::deduce_type() {
    if (std::is_same<T, float>::value)
        return TF_FLOAT;
    if (std::is_same<T, double>::value)
        return TF_DOUBLE;
    if (std::is_same<T, int32_t >::value)
        return TF_INT32;
    if (std::is_same<T, uint8_t>::value)
        return TF_UINT8;
    if (std::is_same<T, int16_t>::value)
        return TF_INT16;
    if (std::is_same<T, int8_t>::value)
        return TF_INT8;
    if (std::is_same<T, int64_t>::value)
        return TF_INT64;
//    if constexpr (std::is_same<T, bool>::value)
//        return TF_BOOL;
    if (std::is_same<T, uint16_t>::value)
        return TF_UINT16;
    if (std::is_same<T, uint32_t>::value)
        return TF_UINT32;
    if (std::is_same<T, uint64_t>::value)
        return TF_UINT64;

    throw std::runtime_error{"Could not deduce type!"};
}

void TensorImpl::deduce_shape() {
    // Get number of dimensions
    int n_dims = TF_NumDims(this->val);

    // If is not a scalar
    if (n_dims > 0) {
        // Get dimensions
        this->shape = std::vector<int64_t>(n_dims, -1);
        for (int i=0; i<n_dims; i++) {
            this->shape[i] = TF_Dim(this->val, i);
        }
    }
}


// VALID deduce_type TEMPLATES
template TF_DataType TensorImpl::deduce_type<float>();
template TF_DataType TensorImpl::deduce_type<double>();
//template TF_DataType Tensor::deduce_type<bool>();
template TF_DataType TensorImpl::deduce_type<int8_t>();
template TF_DataType TensorImpl::deduce_type<int16_t>();
template TF_DataType TensorImpl::deduce_type<int32_t>();
template TF_DataType TensorImpl::deduce_type<int64_t>();
template TF_DataType TensorImpl::deduce_type<uint8_t>();
template TF_DataType TensorImpl::deduce_type<uint16_t>();
template TF_DataType TensorImpl::deduce_type<uint32_t>();
template TF_DataType TensorImpl::deduce_type<uint64_t>();

// VALID get_data TEMPLATES
template std::vector<float> TensorImpl::get_data<float>();
template std::vector<double> TensorImpl::get_data<double>();
template std::vector<bool> TensorImpl::get_data<bool>();
template std::vector<int8_t> TensorImpl::get_data<int8_t>();
template std::vector<int16_t> TensorImpl::get_data<int16_t>();
template std::vector<int32_t> TensorImpl::get_data<int32_t>();
template std::vector<int64_t> TensorImpl::get_data<int64_t>();
template std::vector<uint8_t> TensorImpl::get_data<uint8_t>();
template std::vector<uint16_t> TensorImpl::get_data<uint16_t>();
template std::vector<uint32_t> TensorImpl::get_data<uint32_t>();
template std::vector<uint64_t> TensorImpl::get_data<uint64_t>();

// VALID set_data TEMPLATES
template void TensorImpl::set_data<float>(std::vector<float> new_data);
template void TensorImpl::set_data<double>(std::vector<double> new_data);
//template void Tensor::set_data<bool>(std::vector<bool> new_data);
template void TensorImpl::set_data<int8_t>(std::vector<int8_t> new_data);
template void TensorImpl::set_data<int16_t>(std::vector<int16_t> new_data);
template void TensorImpl::set_data<int32_t>(std::vector<int32_t> new_data);
template void TensorImpl::set_data<int64_t>(std::vector<int64_t> new_data);
template void TensorImpl::set_data<uint8_t>(std::vector<uint8_t> new_data);
template void TensorImpl::set_data<uint16_t>(std::vector<uint16_t> new_data);
template void TensorImpl::set_data<uint32_t>(std::vector<uint32_t> new_data);
template void TensorImpl::set_data<uint64_t>(std::vector<uint64_t> new_data);

// VALID set_data TEMPLATES
template void TensorImpl::set_data<float>(std::vector<float> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<double>(std::vector<double> new_data, const std::vector<int64_t>& new_shape);
//template void Tensor::set_data<bool>(std::vector<bool> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<int8_t>(std::vector<int8_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<int16_t>(std::vector<int16_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<int32_t>(std::vector<int32_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<int64_t>(std::vector<int64_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<uint8_t>(std::vector<uint8_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<uint16_t>(std::vector<uint16_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<uint32_t>(std::vector<uint32_t> new_data, const std::vector<int64_t>& new_shape);
template void TensorImpl::set_data<uint64_t>(std::vector<uint64_t> new_data, const std::vector<int64_t>& new_shape);

Tensor::Tensor(const Model& model, const std::string& operation)
  : m_pImpl(new TensorImpl(*(model.m_pImpl), operation))
{
}

Tensor::~Tensor()
{
  delete m_pImpl;
  m_pImpl = nullptr;
}

void Tensor::clean()
{
  return m_pImpl->clean();
}

std::vector<int64_t> Tensor::get_shape()
{
  return m_pImpl->get_shape();
}

void Tensor::error_check(bool condition, const std::string& error)
{
  return m_pImpl->error_check(condition, error);
}

void Tensor::deduce_shape()
{
  return m_pImpl->deduce_shape();
}

template<> void Tensor::set_data<int8_t>(std::vector<int8_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<int16_t>(std::vector<int16_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<int32_t>(std::vector<int32_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<int64_t>(std::vector<int64_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<uint8_t>(std::vector<uint8_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<uint16_t>(std::vector<uint16_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<uint32_t>(std::vector<uint32_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<uint64_t>(std::vector<uint64_t> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<float>(std::vector<float> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<double>(std::vector<double> new_data) { return m_pImpl->set_data(new_data); }
template<> void Tensor::set_data<int8_t>(std::vector<int8_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<int16_t>(std::vector<int16_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<int32_t>(std::vector<int32_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<int64_t>(std::vector<int64_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<uint8_t>(std::vector<uint8_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<uint16_t>(std::vector<uint16_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<uint32_t>(std::vector<uint32_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<uint64_t>(std::vector<uint64_t> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<float>(std::vector<float> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }
template<> void Tensor::set_data<double>(std::vector<double> new_data, const std::vector<int64_t>& new_shape) { return m_pImpl->set_data(new_data, new_shape); }

template<> std::vector<int8_t> Tensor::get_data<int8_t>()     { return m_pImpl->get_data<int8_t>(); }
template<> std::vector<int16_t> Tensor::get_data<int16_t>()   { return m_pImpl->get_data<int16_t>(); }
template<> std::vector<int32_t> Tensor::get_data<int32_t>()   { return m_pImpl->get_data<int32_t>(); }
template<> std::vector<int64_t> Tensor::get_data<int64_t>()   { return m_pImpl->get_data<int64_t>(); }
template<> std::vector<uint8_t> Tensor::get_data<uint8_t>()   { return m_pImpl->get_data<uint8_t>(); }
template<> std::vector<uint16_t> Tensor::get_data<uint16_t>() { return m_pImpl->get_data<uint16_t>(); }
template<> std::vector<uint32_t> Tensor::get_data<uint32_t>() { return m_pImpl->get_data<uint32_t>(); }
template<> std::vector<uint64_t> Tensor::get_data<uint64_t>() { return m_pImpl->get_data<uint64_t>(); }
template<> std::vector<float> Tensor::get_data<float>()       { return m_pImpl->get_data<float>(); }
template<> std::vector<double> Tensor::get_data<double>()     { return m_pImpl->get_data<double>(); }

template<> static int64_t Tensor::deduce_type<int8_t>() { return (int64_t)(TensorImpl::deduce_type<int8_t>()); }
template<> static int64_t Tensor::deduce_type<int16_t>() { return (int64_t)(TensorImpl::deduce_type<int16_t>()); }
template<> static int64_t Tensor::deduce_type<int32_t>() { return (int64_t)(TensorImpl::deduce_type<int32_t>()); }
template<> static int64_t Tensor::deduce_type<int64_t>() { return (int64_t)(TensorImpl::deduce_type<int64_t>()); }
template<> static int64_t Tensor::deduce_type<uint8_t>() { return (int64_t)(TensorImpl::deduce_type<uint8_t>()); }
template<> static int64_t Tensor::deduce_type<uint16_t>() { return (int64_t)(TensorImpl::deduce_type<uint16_t>()); }
template<> static int64_t Tensor::deduce_type<uint32_t>() { return (int64_t)(TensorImpl::deduce_type<uint32_t>()); }
template<> static int64_t Tensor::deduce_type<uint64_t>() { return (int64_t)(TensorImpl::deduce_type<uint64_t>()); }
template<> static int64_t Tensor::deduce_type<float>() { return (int64_t)(TensorImpl::deduce_type<float>()); }
template<> static int64_t Tensor::deduce_type<double>() { return (int64_t)(TensorImpl::deduce_type<double>()); }


#include "../include/Model.h"




ModelImpl::ModelImpl(const std::string& ModelImpl_filename, const std::vector<uint8_t>& config_options) {
  this->status = TF_NewStatus();
  this->graph = TF_NewGraph();

  // Create the session.
  TF_SessionOptions* sess_opts = TF_NewSessionOptions();

  if (!config_options.empty())
  {
    TF_SetConfig(sess_opts, static_cast<const void*>(config_options.data()), config_options.size(), this->status);
    this->status_check(true);
  }

  this->session = TF_NewSession(this->graph, sess_opts, this->status);
  TF_DeleteSessionOptions(sess_opts);

  // Check the status
  this->status_check(true);

  // Create the graph
  TF_Graph* g = this->graph;


  // Import the graph definition
  TF_Buffer* def = read(ModelImpl_filename);
  this->error_check(def != nullptr, "An error occurred reading the ModelImpl");

  TF_ImportGraphDefOptions* graph_opts = TF_NewImportGraphDefOptions();
  TF_GraphImportGraphDef(g, def, graph_opts, this->status);
  this->status_check(true);
  TF_DeleteImportGraphDefOptions(graph_opts);
  this->status_check(true);
  TF_DeleteBuffer(def);


  this->status_check(true);
}

ModelImpl::~ModelImpl() {
  TF_DeleteSession(this->session, this->status);
  TF_DeleteGraph(this->graph);
  this->status_check(true);
  TF_DeleteStatus(this->status);
}


void ModelImpl::init() {
  TF_Operation* init_op[1] = { TF_GraphOperationByName(this->graph, "init") };

  this->error_check(init_op[0] != nullptr, "Error: No operation named \"init\" exists");

  TF_SessionRun(this->session, nullptr, nullptr, nullptr, 0, nullptr, nullptr, 0, init_op, 1, nullptr, this->status);
  this->status_check(true);
}

void ModelImpl::save(const std::string& ckpt) {
#ifdef TENSORFLOW_C_TF_TSTRING_H_
  std::unique_ptr<TF_TString, decltype(&TF_TString_Dealloc)> tstr(new TF_TString, &TF_TString_Dealloc);
  TF_TString_Copy(tstr.get(), ckpt.c_str(), ckpt.size());
  auto deallocator = [](void* data, size_t len, void* arg) {};
  TF_Tensor* t = TF_NewTensor(TF_STRING, nullptr, 0, tstr.get(), 1, deallocator, nullptr);
#else
  // Encode file_name to tensor
  size_t size = 8 + TF_StringEncodedSize(ckpt.length());
  TF_Tensor* t = TF_AllocateTensor(TF_STRING, nullptr, 0, size);
  char* data = static_cast<char*>(TF_TensorData(t));
  for (int i = 0; i < 8; i++) { data[i] = 0; }
  TF_StringEncode(ckpt.c_str(), ckpt.size(), data + 8, size - 8, status);

  memset(data, 0, 8);  // 8-byte offset of first string.
  TF_StringEncode(ckpt.c_str(), ckpt.length(), (char*)(data + 8), size - 8, status);
#endif // TENSORFLOW_C_TF_TSTRING_H_

  // Check errors
  if (!this->status_check(false)) {
    TF_DeleteTensor(t);
    std::cerr << "Error during filename " << ckpt << " encoding" << std::endl;
    this->status_check(true);
  }

  TF_Output output_file;
  output_file.oper = TF_GraphOperationByName(this->graph, "save/Const");
  output_file.index = 0;
  TF_Output inputs[1] = { output_file };

  TF_Tensor* input_values[1] = { t };
  const TF_Operation* restore_op[1] = { TF_GraphOperationByName(this->graph, "save/control_dependency") };
  if (!restore_op[0]) {
    TF_DeleteTensor(t);
    this->error_check(false, "Error: No operation named \"save/control_dependencyl\" exists");
  }


  TF_SessionRun(this->session, nullptr, inputs, input_values, 1, nullptr, nullptr, 0, restore_op, 1, nullptr, this->status);
  TF_DeleteTensor(t);

  this->status_check(true);
}

void ModelImpl::restore(const std::string& ckpt) {
#ifdef TENSORFLOW_C_TF_TSTRING_H_
  std::unique_ptr<TF_TString, decltype(&TF_TString_Dealloc)> tstr(new TF_TString, &TF_TString_Dealloc);
  TF_TString_Copy(tstr.get(), ckpt.c_str(), ckpt.size());
  auto deallocator = [](void* data, size_t len, void* arg) {};
  TF_Tensor* t = TF_NewTensor(TF_STRING, nullptr, 0, tstr.get(), 1, deallocator, nullptr);
#else
  // Encode file_name to tensor
  size_t size = 8 + TF_StringEncodedSize(ckpt.size());
  TF_Tensor* t = TF_AllocateTensor(TF_STRING, nullptr, 0, size);
  char* data = static_cast<char*>(TF_TensorData(t));
  for (int i = 0; i < 8; i++) { data[i] = 0; }
  TF_StringEncode(ckpt.c_str(), ckpt.size(), data + 8, size - 8, status);
#endif // TENSORFLOW_C_TF_TSTRING_H_

  // Check errors
  if (!this->status_check(false)) {
    TF_DeleteTensor(t);
    std::cerr << "Error during filename " << ckpt << " encoding" << std::endl;
    this->status_check(true);
  }

  TF_Output output_file;
  output_file.oper = TF_GraphOperationByName(this->graph, "save/Const");
  output_file.index = 0;
  TF_Output inputs[1] = { output_file };

  TF_Tensor* input_values[1] = { t };
  const TF_Operation* restore_op[1] = { TF_GraphOperationByName(this->graph, "save/restore_all") };
  if (!restore_op[0]) {
    TF_DeleteTensor(t);
    this->error_check(false, "Error: No operation named \"save/restore_all\" exists");
  }



  TF_SessionRun(this->session, nullptr, inputs, input_values, 1, nullptr, nullptr, 0, restore_op, 1, nullptr, this->status);
  TF_DeleteTensor(t);

  this->status_check(true);
}

TF_Buffer* ModelImpl::read(const std::string& filename) {
  std::ifstream file(filename, std::ios::binary | std::ios::ate);

  // Error opening the file
  if (!file.is_open()) {
    std::cerr << "Unable to open file: " << filename << std::endl;
    return nullptr;
  }


  // Cursor is at the end to get size
  auto size = file.tellg();
  // Move cursor to the beginning
  file.seekg(0, std::ios::beg);

  // Read
  auto data = std::make_unique<char[]>(size);
  file.seekg(0, std::ios::beg);
  file.read(data.get(), size);

  // Error reading the file
  if (!file) {
    std::cerr << "Unable to read the full file: " << filename << std::endl;
    return nullptr;
  }


  // Create tensorflow buffer from read data
  TF_Buffer* buffer = TF_NewBufferFromString(data.get(), size);

  // Close file and remove data
  file.close();

  return buffer;
}

std::vector<std::string> ModelImpl::get_operations() const {
  std::vector<std::string> result;
  size_t pos = 0;
  TF_Operation* oper;

  // Iterate through the operations of a graph
  while ((oper = TF_GraphNextOperation(this->graph, &pos)) != nullptr) {
    result.emplace_back(TF_OperationName(oper));
  }

  return result;
}

void ModelImpl::run(const std::vector<TensorImpl*>& inputs, const std::vector<TensorImpl*>& outputs) {

  this->error_check(std::all_of(inputs.begin(), inputs.end(), [](const TensorImpl* i) {return i->flag == 1; }),
    "Error: Not all elements from the inputs are full");

  this->error_check(std::all_of(outputs.begin(), outputs.end(), [](const TensorImpl* o) {return o->flag != -1; }),
    "Error: Not all outputs Tensors are valid");


  // Clean previous stored outputs
  std::for_each(outputs.begin(), outputs.end(), [](TensorImpl* o) {o->clean(); });

  // Get input operations
  std::vector<TF_Output> io(inputs.size());
  std::transform(inputs.begin(), inputs.end(), io.begin(), [](const TensorImpl* i) {return i->op; });

  // Get input values
  std::vector<TF_Tensor*> iv(inputs.size());
  std::transform(inputs.begin(), inputs.end(), iv.begin(), [](const TensorImpl* i) {return i->val; });

  // Get output operations
  std::vector<TF_Output> oo(outputs.size());
  std::transform(outputs.begin(), outputs.end(), oo.begin(), [](const TensorImpl* o) {return o->op; });

  // Prepare output recipients
  auto ov = new TF_Tensor * [outputs.size()];

  TF_SessionRun(this->session, nullptr, io.data(), iv.data(), inputs.size(), oo.data(), ov, outputs.size(), nullptr, 0, nullptr, this->status);
  this->status_check(true);

  // Save results on outputs and mark as full
  for (std::size_t i = 0; i < outputs.size(); i++) {
    outputs[i]->val = ov[i];
    outputs[i]->flag = 1;
    outputs[i]->deduce_shape();
  }

  // Mark input as empty
  std::for_each(inputs.begin(), inputs.end(), [](TensorImpl* i) {i->clean(); });

  delete[] ov;
}

void ModelImpl::run(TensorImpl& input, TensorImpl& output) {
  this->run(&input, &output);
}

void ModelImpl::run(const std::vector<TensorImpl*>& inputs, TensorImpl& output) {
  this->run(inputs, &output);
}

void ModelImpl::run(TensorImpl& input, const std::vector<TensorImpl*>& outputs) {
  this->run(&input, outputs);
}

void ModelImpl::run(TensorImpl* input, TensorImpl* output) {
  this->run(std::vector<TensorImpl*>({ input }), std::vector<TensorImpl*>({ output }));
}

void ModelImpl::run(const std::vector<TensorImpl*>& inputs, TensorImpl* output) {
  this->run(inputs, std::vector<TensorImpl*>({ output }));
}

void ModelImpl::run(TensorImpl* input, const std::vector<TensorImpl*>& outputs) {
  this->run(std::vector<TensorImpl*>({ input }), outputs);
}

bool ModelImpl::status_check(bool throw_exc) const {

  if (TF_GetCode(this->status) != TF_OK) {
    if (throw_exc) {
      throw std::runtime_error(TF_Message(status));
    }
    else {
      return false;
    }
  }
  return true;
}

void ModelImpl::error_check(bool condition, const std::string& error) const {
  if (!condition) {
    throw std::runtime_error(error);
  }
}


Model::Model(const std::string& model_filename, const std::vector<uint8_t>& config_options /*= {}*/)
  : m_pImpl(new ModelImpl(model_filename, config_options))
{
}

Model::~Model()
{
  delete m_pImpl;
  m_pImpl = nullptr;
}

void Model::init()
{
  return m_pImpl->init();
}

void Model::restore(const std::string& ckpt)
{
  return m_pImpl->restore(ckpt);
}

void Model::save(const std::string& ckpt)
{
  return m_pImpl->save(ckpt);
}

std::vector<std::string> Model::get_operations() const
{
  return m_pImpl->get_operations();
}

void Model::run(const std::vector<Tensor*>& inputs, const std::vector<Tensor*>& outputs)
{
  std::vector<TensorImpl*> _inputs;
  std::vector<TensorImpl*> _outputs;
  for (size_t i = 0; i < inputs.size(); i++)
    _inputs.push_back(inputs[i]->m_pImpl);
  for (size_t i = 0; i < outputs.size(); i++)
    _outputs.push_back(outputs[i]->m_pImpl);
  return m_pImpl->run(_inputs, _outputs);
}

void Model::run(Tensor& input, const std::vector<Tensor*>& outputs)
{
  std::vector<TensorImpl*> _outputs;
  for (size_t i = 0; i < outputs.size(); i++)
    _outputs.push_back(outputs[i]->m_pImpl);
  return m_pImpl->run(*(input.m_pImpl), _outputs);
}

void Model::run(const std::vector<Tensor*>& inputs, Tensor& output)
{
  std::vector<TensorImpl*> _inputs;
  for (size_t i = 0; i < inputs.size(); i++)
    _inputs.push_back(inputs[i]->m_pImpl);
  return m_pImpl->run(_inputs, *(output.m_pImpl));
}

void Model::run(Tensor& input, Tensor& output)
{
  return m_pImpl->run(*(input.m_pImpl), *(output.m_pImpl));
}

void Model::run(Tensor* input, const std::vector<Tensor*>& outputs)
{
  std::vector<TensorImpl*> _outputs;
  for (size_t i = 0; i < outputs.size(); i++)
    _outputs.push_back(outputs[i]->m_pImpl);
  return m_pImpl->run(input->m_pImpl, _outputs);
}

void Model::run(const std::vector<Tensor*>& inputs, Tensor* output)
{
  std::vector<TensorImpl*> _inputs;
  for (size_t i = 0; i < inputs.size(); i++)
    _inputs.push_back(inputs[i]->m_pImpl);
  return m_pImpl->run(_inputs, output->m_pImpl);
}

void Model::run(Tensor* input, Tensor* output)
{
  return m_pImpl->run(input->m_pImpl, output->m_pImpl);
}

TF_Buffer* Model::read(const std::string& val)
{
  return ModelImpl::read(val);
}

bool Model::status_check(bool throw_exc) const
{
  return m_pImpl->status_check(throw_exc);
}

void Model::error_check(bool condition, const std::string& error) const
{
  return m_pImpl->error_check(condition, error);
}
