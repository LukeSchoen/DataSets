//
// Created by sergio on 13/05/19.
//

#ifndef CPPFLOW_TENSOR_H
#define CPPFLOW_TENSOR_H

#include <vector>
#include <memory>
#include <string>
#include <algorithm>
#include <numeric>
#include <cstring>
#include "Model.h"

class TensorImpl;
class Model;

class Tensor {
public:
    Tensor(const Model& model, const std::string& operation);

    // Rule of five, moving is easy as the pointers can be copied, copying not as i have no idea how to copy
    // the contents of the pointer (i guess dereferencing won't do a deep copy)
    Tensor(const Tensor &tensor) = delete;
    Tensor(Tensor &&tensor) = default;
    Tensor& operator=(const Tensor &tensor) = delete;
    Tensor& operator=(Tensor &&tensor) = default;

    ~Tensor();

    void clean();

    template<typename T>
    void set_data(std::vector<T> new_data) {
      throw std::exception("Not implemented for T");
    };

    template<typename T>
    void set_data(std::vector<T> new_data, const std::vector<int64_t>& new_shape)
    {
      throw std::exception("Not implemented for T");
    };


    template<typename T>
    std::vector<T> get_data()
    {
      throw std::exception("Not implemented for T");
    };

	std::vector<int64_t> get_shape();

private:
    // Aux functions
    void error_check(bool condition, const std::string& error);

    template <typename T>
    static int64_t deduce_type() {
      throw std::exception("Not implemented for T");
    }

    void deduce_shape();

    TensorImpl* m_pImpl;

public:
    friend class Model;
};

template<> void Tensor::set_data<int8_t>  (std::vector<int8_t> new_data);
template<> void Tensor::set_data<int16_t> (std::vector<int16_t> new_data);
template<> void Tensor::set_data<int32_t> (std::vector<int32_t> new_data);
template<> void Tensor::set_data<int64_t> (std::vector<int64_t> new_data);
template<> void Tensor::set_data<uint8_t> (std::vector<uint8_t> new_data);
template<> void Tensor::set_data<uint16_t>(std::vector<uint16_t> new_data);
template<> void Tensor::set_data<uint32_t>(std::vector<uint32_t> new_data);
template<> void Tensor::set_data<uint64_t>(std::vector<uint64_t> new_data);
template<> void Tensor::set_data<float>   (std::vector<float> new_data);
template<> void Tensor::set_data<double>  (std::vector<double> new_data);
template<> void Tensor::set_data<int8_t>(std::vector<int8_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<int16_t>(std::vector<int16_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<int32_t>(std::vector<int32_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<int64_t>(std::vector<int64_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<uint8_t>(std::vector<uint8_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<uint16_t>(std::vector<uint16_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<uint32_t>(std::vector<uint32_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<uint64_t>(std::vector<uint64_t> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<float>(std::vector<float> new_data, const std::vector<int64_t>& new_shape);
template<> void Tensor::set_data<double>(std::vector<double> new_data, const std::vector<int64_t>& new_shape);

template<> std::vector<int8_t> Tensor::get_data<int8_t>();
template<> std::vector<int16_t> Tensor::get_data<int16_t>();
template<> std::vector<int32_t> Tensor::get_data<int32_t>();
template<> std::vector<int64_t> Tensor::get_data<int64_t>();
template<> std::vector<uint8_t> Tensor::get_data<uint8_t>();
template<> std::vector<uint16_t> Tensor::get_data<uint16_t>();
template<> std::vector<uint32_t> Tensor::get_data<uint32_t>();
template<> std::vector<uint64_t> Tensor::get_data<uint64_t>();
template<> std::vector<float> Tensor::get_data<float>();
template<> std::vector<double> Tensor::get_data<double>();

template<> static int64_t Tensor::deduce_type<int8_t>();
template<> static int64_t Tensor::deduce_type<int16_t>();
template<> static int64_t Tensor::deduce_type<int32_t>();
template<> static int64_t Tensor::deduce_type<int64_t>();
template<> static int64_t Tensor::deduce_type<uint8_t>();
template<> static int64_t Tensor::deduce_type<uint16_t>();
template<> static int64_t Tensor::deduce_type<uint32_t>();
template<> static int64_t Tensor::deduce_type<uint64_t>();
template<> static int64_t Tensor::deduce_type<float>();
template<> static int64_t Tensor::deduce_type<double>();

#endif //CPPFLOW_TENSOR_H
